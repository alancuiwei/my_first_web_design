# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Ver01::Application.config.secret_token = '52e9fce7b20c2b8265290ffc250be16e1ac5d5b3da8399440c53b6377ba697043ad2142912f209224ad4adee58a583e02088cfcae44d95b9e389671764b63cac'
