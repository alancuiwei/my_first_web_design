class UsersurveyController < ApplicationController
  def index

  end
end
