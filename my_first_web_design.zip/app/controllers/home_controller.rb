#encoding: utf-8
class HomeController < ApplicationController
  def index
  end
  def productindex
  end
end
