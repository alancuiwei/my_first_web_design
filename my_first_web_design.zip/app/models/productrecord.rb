#encoding: utf-8
class Productrecord < ActiveRecord::Base
end
