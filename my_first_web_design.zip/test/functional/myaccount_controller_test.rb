require 'test_helper'

class MyaccountControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
