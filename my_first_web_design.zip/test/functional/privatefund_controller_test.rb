require 'test_helper'

class PrivatefundControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
