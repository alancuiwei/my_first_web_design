require 'test_helper'

class BankinvestHelperTest < ActionView::TestCase
end
