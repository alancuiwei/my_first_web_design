require 'test_helper'

class ContactusHelperTest < ActionView::TestCase
end
