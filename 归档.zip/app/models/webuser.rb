#encoding: utf-8
class Webuser < ActiveRecord::Base
	end
