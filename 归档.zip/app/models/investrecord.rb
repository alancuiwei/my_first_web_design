#encoding: utf-8
class Investrecord < ActiveRecord::Base
end
