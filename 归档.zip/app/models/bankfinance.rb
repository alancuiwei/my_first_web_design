#encoding: utf-8
class Bankfinance < ActiveRecord::Base
end
