#encoding: utf-8
class Product < ActiveRecord::Base
end
