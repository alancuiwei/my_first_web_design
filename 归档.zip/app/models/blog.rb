#encoding: utf-8
class Blog < ActiveRecord::Base
end
