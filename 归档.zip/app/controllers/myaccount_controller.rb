class MyaccountController < ApplicationController

  def index

  end

    end
