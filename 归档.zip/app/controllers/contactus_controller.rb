#encoding: utf-8

class ContactusController < ApplicationController
  def aboutus
  end
end
