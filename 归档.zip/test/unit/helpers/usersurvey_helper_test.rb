require 'test_helper'

class UsersurveyHelperTest < ActionView::TestCase
end
