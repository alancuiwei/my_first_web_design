require 'test_helper'

class PrivatefundHelperTest < ActionView::TestCase
end
