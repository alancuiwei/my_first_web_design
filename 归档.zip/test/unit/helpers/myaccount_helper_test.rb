require 'test_helper'

class MyaccountHelperTest < ActionView::TestCase
end
