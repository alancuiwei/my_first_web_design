require 'test_helper'

class UsersurveyControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
